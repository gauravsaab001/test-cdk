import * as cdk from '@aws-cdk/core';
import { Construct } from 'constructs';
import * as sqs from '@aws-cdk/aws-sqs';
import { App } from 'aws-cdk-lib';
import * as iam from '@aws-cdk/aws-iam';

export class SampleStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Define an SQS queue
    const queue = new sqs.Queue(this, 'MyQueue', {
      visibilityTimeout: cdk.Duration.seconds(300), // Optional: Set visibility timeout
      retentionPeriod: cdk.Duration.days(7) // Optional: Set retention period
      // Other configuration options can be added as needed
    });

    // You can grant permissions to other AWS resources to interact with this SQS queue
    // For example, granting S3 read/write access to the queue
    // queue.grantReadWrite(myS3Bucket);
  }
}


const accountB={
account:'363704604438',
region:'us-west-2'
 };

const app = new cdk.App();
new SampleStack(app, 'SampleStack',{env:accountB});
app.synth();



