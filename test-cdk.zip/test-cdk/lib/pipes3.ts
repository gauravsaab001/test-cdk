//import * as cdk from '@aws-cdk/core';
import * as codedeploy from '@aws-cdk/aws-codedeploy';
//import * as codepipeline from '@aws-cdk/aws-codepipeline';
import * as actions from '@aws-cdk/aws-codepipeline-actions';
import * as cdk from '@aws-cdk/core';
import * as CodeBuild from "@aws-cdk/aws-codebuild";
import * as codepipeline from "@aws-cdk/aws-codepipeline";
import * as CodePipelineAction from "@aws-cdk/aws-codepipeline-actions";
import * as s3 from "@aws-cdk/aws-s3";
import * as Lambda from "@aws-cdk/aws-lambda";
import * as sns from '@aws-cdk/aws-sns';
import * as subs from '@aws-cdk/aws-sns-subscriptions';
import * as codepipeline_notifications from '@aws-cdk/aws-codestarnotifications';
import * as subscriptions from '@aws-cdk/aws-sns-subscriptions';
import * as ec2 from '@aws-cdk/aws-ec2';
import * as iam from '@aws-cdk/aws-iam';
import * as events from '@aws-cdk/aws-events';
import * as target from '@aws-cdk/aws-events-targets';

export class MyPipelineStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const bucket = new s3.Bucket(this, 'MyBucket-pl', {
      bucketName: 'my-bucket-name-pl', // Optional: Specify the bucket name
      removalPolicy: cdk.RemovalPolicy.DESTROY, // Optional: Specify the removal policy
     // autoDeleteObjects: true, // Optional: Automatically delete objects when the bucket is deleted
      versioned: true, // Optional: Enable versioning for the bucket
      encryption: s3.BucketEncryption.S3_MANAGED, // Optional: Specify encryption settings
      // Other bucket properties
    });

// AWS CodeBuild artifacts
const outputSources = new codepipeline.Artifact();
//const outputWebsite = new codepipeline.Artifact();


 // Define an SNS topic for notifications -- new
const notificationTopic = new sns.Topic(this, 'NotificationTopic');

// Subscribe an email address to the SNS topic (optional)
notificationTopic.addSubscription(new subscriptions.EmailSubscription('gauravsaab001@gmail.com'));

// Create the pipeline
const pipeline = new codepipeline.Pipeline(this, 'MyPipeline', {
  pipelineName: 'MyPipeline-adhoc'
});

// Define a notification rule for pipeline state changes -- new
const notificationRule = new codepipeline_notifications.CfnNotificationRule(this, 'NotificationRule', {
  name: 'PipelineStateChangeRule',
  detailType: 'FULL',
  eventTypeIds: [
    'codepipeline-pipeline-pipeline-execution-failed',
    'codepipeline-pipeline-pipeline-execution-canceled'
  ],
  resource: pipeline.pipelineArn,
  targets: [{
    targetType: 'SNS',
    targetAddress: notificationTopic.topicArn,
  }],
});

    // Source stage: Pull source code from GitHub or another repository
    const sourceOutput = new codepipeline.Artifact();
    const sourceAction = new actions.GitHubSourceAction({
     actionName: 'GitHub_Source',
      owner: 'gauravsaab001',
      repo: 'testapp',
      oauthToken: cdk.SecretValue.secretsManager('mypieplinegithub'),
      output: sourceOutput,
      branch: 'main' // or the branch you want to deploy from
    });
    
     

    // Approval stage: Manual approval before deployment
    const manualApprovalAction = new actions.ManualApprovalAction({
      actionName: 'ManualApproval',
      additionalInformation: 'Approve to deploy to production'
    });

    // Deployment stage: Deploy using AWS CodeDeploy
    const application = new codedeploy.ServerApplication(this, 'MyApp');
    //const deploymentGroup = new codedeploy.ServerDeploymentGroup(this, 'MyDeploymentGroup', {
    //  application,
    //  deploymentGroupName: 'MyDeploymentGroup'
    //});

    // Define CodeDeploy deployment group
    const deploymentGroup = new codedeploy.ServerDeploymentGroup(this, 'MyCodeDeployDeploymentGroup', {
      deploymentGroupName: 'MyCodeDeployDeploymentGroup',
      application,
     // instanceType: [instance],
    });
    
    // Add stages to the pipeline
    const sourceStage = pipeline.addStage({
      stageName: 'Source',
      actions: [sourceAction]
    });


    const approvalStage = pipeline.addStage({
      stageName: 'Approval',
      actions: [manualApprovalAction]
    });

      
// Create a CodeDeploy action
const deployAction = new CodePipelineAction.CodeDeployServerDeployAction({
  actionName: 'DeployAction',
  deploymentGroup,
  //input: sourceStage.actions[0].actionProperties.outputs[0], // Assuming source action produces an artifact
  input: sourceOutput,
});

const deployStage =  pipeline.addStage({
  stageName: 'Deploy',
  actions: [deployAction]
});

    
// Define an event rule
const rule = new events.Rule(this, 'S3EventRule', {
  eventPattern: {
    source: ['aws.s3'],
    detailType: ['AWS API Call via CloudTrail'],
    detail: {
      eventSource: ['s3.amazonaws.com'],
      eventName: ['PutObject', 'DeleteObject'], // Specify the S3 events you want to listen to
      requestParameters: {
        bucketName: [bucket.bucketName],
      },
    },
  },
});

// Subscribe the SNS topic to the event rule
rule.addTarget(new target.SnsTopic(notificationTopic));
    
    //deployStage.addAction(deployAction);
    
  }
}









