import * as CDK from "@aws-cdk/core";
import * as CodeBuild from "@aws-cdk/aws-codebuild";
import * as CodePipeline from "@aws-cdk/aws-codepipeline";
import * as CodePipelineAction from "@aws-cdk/aws-codepipeline-actions";
import * as S3 from "@aws-cdk/aws-s3";
import * as Lambda from "@aws-cdk/aws-lambda";

export class InfraStack extends CDK.Stack {
  constructor(scope: CDK.App, id: string, props: any) {
    super(scope, id, props);

    // AWS CodeBuild artifacts
    const outputSources = new CodePipeline.Artifact();
    const outputWebsite = new CodePipeline.Artifact();

    // Custom CloudFormation parameter to determine if resources should be created
    const createResourcesParam = new CDK.CfnParameter(this, 'CreateResources', {
      type: 'String',
      default: 'true', // Set to 'true' to create resources by default
    });

    // Create S3 bucket conditionally based on the parameter
    const s3Bucket = createResourcesParam.valueAsString === 'true' ?
      new S3.Bucket(this, 'exampBucket', {
        objectOwnership: S3.ObjectOwnership.BUCKET_OWNER_ENFORCED,
        blockPublicAccess: S3.BlockPublicAccess.BLOCK_ALL,
      }) : undefined;

    // Lambda layer conditionally based on the parameter
    const lambdaLayer = createResourcesParam.valueAsString === 'true' ?
      new Lambda.LayerVersion(this, "MyLambdaLayer", {
        compatibleRuntimes: [Lambda.Runtime.NODEJS_16_X],
        code: Lambda.Code.fromAsset("./lambda-layers-nodejs/lambda-layer-nodejs.zip"),
      }) : undefined;

    // Lambda function using the layer conditionally based on the parameter
    const lambdaFunction = createResourcesParam.valueAsString === 'true' ?
      new Lambda.Function(this, "MyLambdaFunction", {
        runtime: Lambda.Runtime.NODEJS_16_X,
        handler: "index.handler",
        code: Lambda.Code.fromAsset("./lambda-layers-nodejs/"),
        layers: [lambdaLayer!], // Ensure the layer is defined before using it
      }) : undefined;

    // AWS CodePipeline pipeline
    const pipeline = new CodePipeline.Pipeline(this, "Pipeline", {
      pipelineName: "MyWebsite",
      restartExecutionOnUpdate: true,
    });

    // AWS CodePipeline stage to clone sources from the Bitbucket repository
    pipeline.addStage({
      stageName: "Source",
      actions: [
        new CodePipelineAction.CodeStarConnectionsSourceAction({
          actionName: "Checkout",
          owner: "digital-parkland",
          repo: "testing_repo_CDK_pipeline",
          output: outputSources,
          branch: "master",
          connectionArn: "arn:aws:codestar-connections:us-west-2:544146401463:connection/c798f2a2-62fe-413a-a090-a948f3c602fa",
        }),
      ],
    });

    // AWS CodePipeline stage to build CRA website and CDK resources
    pipeline.addStage({
      stageName: "Build",
      actions: [
        // AWS CodePipeline action to run the CodeBuild project
        new CodePipelineAction.CodeBuildAction({
          actionName: "Website",
          project: new CodeBuild.PipelineProject(this, "BuildWebsite", {
            projectName: "MyWebsite",
            buildSpec: CodeBuild.BuildSpec.fromSourceFilename("./lib/build.yml"),
          }),
          input: outputSources,
          outputs: [outputWebsite],
        }),
      ],
    });

    // AWS CodePipeline manual approval stage
    //pipeline.addStage({
    //stageName: "Approve",
    //actions: [
    //new CodePipelineAction.ManualApprovalAction({
    //actionName: "ManualApproval",
    //}),
     //],
    //});

    

    console.log(`createResourcesParam.valueAsString: ${createResourcesParam.valueAsString}`);

    // AWS CodePipeline stage to deploy the website and CDK resources conditionally
    const deployStageActions = createResourcesParam.valueAsString === 'true' ? [
      // AWS CodePipeline action to deploy the Lambda layer
      new CodePipelineAction.CloudFormationCreateUpdateStackAction({
        actionName: "LambdaLayer",
        templatePath: outputWebsite.atPath('lambda-layer-template.yaml'),
        stackName: 'LambdaLayerStack',
        adminPermissions: true,
      }),

      // AWS CodePipeline action to deploy the website to S3
      new CodePipelineAction.S3DeployAction({
        actionName: "Website",
        input: outputWebsite,
        bucket: s3Bucket!,
      }),
    ] : [
      // Add a dummy action that does nothing, just to satisfy the requirement
      new CodePipelineAction.CodeBuildAction({
        actionName: "DummyDeployAction",
        project: new CodeBuild.PipelineProject(this, "DummyDeployProject", {
          buildSpec: CodeBuild.BuildSpec.fromObject({}),
        }),
        input: outputWebsite,
      }),
    ];

    // AWS CodePipeline stage to deploy the website and CDK resources conditionally
    pipeline.addStage({
      stageName: "Deploy",
      actions: deployStageActions,
    });
  }
}
