//import * as cdk from '@aws-cdk/core';
import * as codedeploy from '@aws-cdk/aws-codedeploy';
//import * as codepipeline from '@aws-cdk/aws-codepipeline';
import * as actions from '@aws-cdk/aws-codepipeline-actions';
import * as cdk from '@aws-cdk/core';
import * as CodeBuild from "@aws-cdk/aws-codebuild";
import * as codepipeline from "@aws-cdk/aws-codepipeline";
import * as CodePipelineAction from "@aws-cdk/aws-codepipeline-actions";
import * as S3 from "@aws-cdk/aws-s3";
import * as Lambda from "@aws-cdk/aws-lambda";
import * as sns from '@aws-cdk/aws-sns';
import * as subs from '@aws-cdk/aws-sns-subscriptions';
import * as codepipeline_notifications from '@aws-cdk/aws-codestarnotifications';
import * as subscriptions from '@aws-cdk/aws-sns-subscriptions';
import * as ec2 from '@aws-cdk/aws-ec2';
import * as iam from '@aws-cdk/aws-iam';
import * as events from '@aws-cdk/aws-events';
import * as target from '@aws-cdk/aws-events-targets';
import * as cloudformation from '@aws-cdk/aws-cloudformation';
import * as cfninc from '@aws-cdk/cloudformation-include';

export class MyPipelineStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Define an IAM role for EC2 instance
    //const role = new iam.Role(this, 'EC2Role', {
    //  assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
    //});

    const template = new cfninc.CfnInclude(this, 'Template', { 
      templateFile: 'lib/ectwo.json',
    });

    const role = new iam.Role(this, 'MyEc2Role', {
      assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'), // Allow EC2 service to assume this role
      roleName: 'MyEc2Role', // Optional: Specify a name for the IAM role
      managedPolicies: [iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore')], // Attach a managed policy
      //inlinePolicies: {
        // Define inline policies here if needed
      //},
      
    });

    // Define the VPC
    //const vpc = new ec2.Vpc(this, 'MyVpc', {
    //  maxAzs: 2, // Specify the maximum availability zones
    //});
    

    // Attach an inline policy to the IAM role
     role.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ['ec2:DescribeInstances'],
      resources: ['*'], // Allow DescribeInstances action on all EC2 instances
    }));
        
    // Define the EC2 instance
    //const instance = new ec2.Instance(this, 'MyInstance', {
    //  instanceType: ec2.InstanceType.of(ec2.InstanceClass.T2, ec2.InstanceSize.MICRO),
    //  machineImage: ec2.MachineImage.latestAmazonLinux({
    //    generation: ec2.AmazonLinuxGeneration.AMAZON_LINUX_2,
     //   
    //  }),
     // vpc,
    //});
   
    

// AWS CodeBuild artifacts
const outputSources = new codepipeline.Artifact();
//const outputWebsite = new codepipeline.Artifact();


 // Define an SNS topic for notifications -- new
const notificationTopic = new sns.Topic(this, 'NotificationTopic');

// Subscribe an email address to the SNS topic (optional)
notificationTopic.addSubscription(new subscriptions.EmailSubscription('gauravsaab001@gmail.com'));

// Create the pipeline
const pipeline = new codepipeline.Pipeline(this, 'MyPipeline', {
  pipelineName: 'MyPipeline-adhoc'
});

// Define a notification rule for pipeline state changes -- new
const notificationRule = new codepipeline_notifications.CfnNotificationRule(this, 'NotificationRule', {
  name: 'PipelineStateChangeRule',
  detailType: 'FULL',
  eventTypeIds: [
    'codepipeline-pipeline-pipeline-execution-failed',
    'codepipeline-pipeline-pipeline-execution-canceled'
  ],
  resource: pipeline.pipelineArn,
  targets: [{
    targetType: 'SNS',
    targetAddress: notificationTopic.topicArn,
  }],
});

    // Source stage: Pull source code from GitHub or another repository
    const sourceOutput = new codepipeline.Artifact();
    const sourceAction = new actions.GitHubSourceAction({
     actionName: 'GitHub_Source',
      owner: 'gauravsaab001',
      repo: 'testapp',
      oauthToken: cdk.SecretValue.secretsManager('mypieplinegithub'),
      output: sourceOutput,
      branch: 'main' // or the branch you want to deploy from
    });
    
     

    // Approval stage: Manual approval before deployment
    const manualApprovalAction = new actions.ManualApprovalAction({
      actionName: 'ManualApproval',
      additionalInformation: 'Approve to deploy to production'
    });

    // Deployment stage: Deploy using AWS CodeDeploy
    const application = new codedeploy.ServerApplication(this, 'MyApp');
    //const deploymentGroup = new codedeploy.ServerDeploymentGroup(this, 'MyDeploymentGroup', {
    //  application,
    //  deploymentGroupName: 'MyDeploymentGroup'
    //});

    // Define CodeDeploy deployment group
    const deploymentGroup = new codedeploy.ServerDeploymentGroup(this, 'MyCodeDeployDeploymentGroup', {
      deploymentGroupName: 'MyCodeDeployDeploymentGroup',
      application,
     // instanceType: [instance],
    });
    
    //const deployAction = new actions.CodeDeployServerDeployAction({
    //  actionName: 'DeployAction',
    //  input: sourceOutput,
    //  deploymentGroup
    //});

    //pipeline removed from here and shifted above 

    // Add stages to the pipeline
    const sourceStage = pipeline.addStage({
      stageName: 'Source',
      actions: [sourceAction]
    });


    const approvalStage = pipeline.addStage({
      stageName: 'Approval',
      actions: [manualApprovalAction]
    });

      
// Create a CodeDeploy action
const deployAction = new CodePipelineAction.CodeDeployServerDeployAction({
  actionName: 'DeployAction',
  deploymentGroup,
  //input: sourceStage.actions[0].actionProperties.outputs[0], // Assuming source action produces an artifact
  input: sourceOutput,
});

const deployStage =  pipeline.addStage({
  stageName: 'Deploy',
  actions: [deployAction]
});

// Subscribe the SNS topic to pipeline state changes
//pipeline.onStateChange('PipelineStateChange', {
//  target: new subscriptions.SnsTopic(notificationTopic),
//  description: 'Notify pipeline state changes',
//});

// Subscribe the SNS topic to stage state changes
//[sourceStage, approvalStage, deployStage].forEach(stage => {
//  stage.onStateChange('StageStateChange', {
//    target: new subscriptions.SnsTopic(notificationTopic),
//    description: `Notify ${stage.stageName} stage state changes`,
//  });
//});
    
// Define an event rule
const rule = new events.Rule(this, 'MyRule', {
  eventPattern: {
    source: ['aws.ec2'],
    detailType: ['EC2 Instance State-change Notification']
  }
});

// Subscribe the SNS topic to the event rule
rule.addTarget(new target.SnsTopic(notificationTopic));
    
pipeline.onStateChange('PipelineStateChangeNotification', {
  target: new target.SnsTopic(notificationTopic),
  eventPattern: {
    detail: {
      state: ['FAILED'],
    },
  },
});
    //deployStage.addAction(deployAction);
    
  }
}









