import * as cdk from '@aws-cdk/core';
import * as iam from '@aws-cdk/aws-iam';
//import * as sts from '@aws-cdk/aws-sts';
import * as sqs from '@aws-cdk/aws-sqs';

export class SampleStack extends cdk.Stack {
    constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
      super(scope, id, props);
  
      // Define an SQS queue
      const queue = new sqs.Queue(this, 'MyQueue', {
        visibilityTimeout: cdk.Duration.seconds(300), // Optional: Set visibility timeout
        retentionPeriod: cdk.Duration.days(7) // Optional: Set retention period
        // Other configuration options can be added as needed
      });
  
      // You can grant permissions to other AWS resources to interact with this SQS queue
      // For example, granting S3 read/write access to the queue
      // queue.grantReadWrite(myS3Bucket);
    }
  }

class CrossAccountDeploymentStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // IAM role in the target account to be assumed
    const targetAccountRole = new iam.Role(this, 'TargetAccountRole', {
      assumedBy: new iam.AccountPrincipal('ASIAX5MNHFC345UZWBYI'), // Replace with the source AWS account ID
      // Add other role configurations as needed
    });

    // Attach a policy granting necessary permissions for CDK deployment
    targetAccountRole.attachInlinePolicy(
      new iam.Policy(this, 'TargetAccountPolicy', {
        statements: [
          // Add policy statements granting permissions for CDK deployment
          // Example:
          new iam.PolicyStatement({
            actions: ['cloudformation:*'], // Adjust permissions as per your requirements
            resources: ['*'], // Adjust resources as per your requirements
          }),
        ],
      })
    );

    // Assume role in the target account
   //const assumedRole = new sts.CfnRole(this, 'AssumedRole', {
    //roleName: targetAccountRole.roleName,
    //roleArn: targetAccountRole.roleArn,
   //Add other role configurations as needed
  //});

    // Set the environment to target the desired AWS account and region
    const env: cdk.Environment = {
      account: 'ASIAVJLT324LNG3HJDXF',
      region: 'us-west-2',
    };

    // Deploy CDK stack to the target account
    new SampleStack(this, 'YourCDKStack', { env });
  }
}

const app = new cdk.App();
new CrossAccountDeploymentStack(app, 'CrossAccountDeploymentStack');
app.synth();
